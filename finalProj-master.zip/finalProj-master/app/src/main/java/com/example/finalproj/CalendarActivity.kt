package com.example.finalproj

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CalendarView
import android.widget.CalendarView.OnDateChangeListener
import android.widget.TextView
import android.widget.Button
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import android.content.Intent
import android.util.Log
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class CalendarActivity : AppCompatActivity() {
    lateinit var dateTV : TextView
    lateinit var calendarView : CalendarView
    lateinit var eventBtn : Button
    lateinit var handler : DataListener
    var dayEvents : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView( R.layout.activity_calendar )

        // initializing variables of
        // list view with their ids.
        dateTV = findViewById( R.id.idTVDate )
        calendarView = findViewById( R.id.calendarView )
        eventBtn = findViewById( R.id.eventsButton )
        handler = DataListener()

        var firebase : FirebaseDatabase = FirebaseDatabase.getInstance()
        lateinit var reference : DatabaseReference

        // on below line we are adding set on
        // date change listener for calendar view.
        calendarView
            .setOnDateChangeListener(
                OnDateChangeListener { view, year, month, dayOfMonth ->
                    // In this Listener we are getting values
                    // such as year, month and day of month
                    // on below line we are creating a variable
                    // in which we are adding all the variables in it.
                    var date : String = ((month + 1).toString() + "-"
                            + dayOfMonth.toString() + "-" + year)
                    // set this date in TextView for Display
                    dateTV.setText(date)
                })

        eventBtn.setOnClickListener {
            if ( dateTV.text.toString() == "Current Date" ) {
                Log.w( "MainActivity", "Please select a date and press Events again")
            } else {
                reference = firebase.getReference( dateTV.text.toString() )
                reference.addValueEventListener( handler )
            }
        }

        // adView
        var adView : AdView = AdView(this)
        var adSize : AdSize = AdSize(AdSize.FULL_WIDTH, AdSize.AUTO_HEIGHT)
        adView.setAdSize(adSize)
        var adUnitId : String = "ca-app-pub-3940256099942544/6300978111"
        adView.adUnitId = adUnitId

        // adrequest
        var builder : AdRequest.Builder = AdRequest.Builder()
        builder.addKeyword("calendar").addKeyword("event)")
        var request : AdRequest = builder.build()

        // put in linear layout
        var adLayout : LinearLayout = findViewById(R.id.ad_view)
        adLayout.addView(adView)

        // load
        adView.loadAd(request)

        val ratingBar: RatingBar = findViewById(R.id.ratingBar)
        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            showToast("Rating: $rating")
        }
    }
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    inner class DataListener : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val myIntent : Intent = Intent( this@CalendarActivity, ScheduleActivity::class.java )
            dayEvents = if ( snapshot.value == null )
                ""
            else
                snapshot.value.toString()
            myIntent.putExtra( "events", dayEvents )
            myIntent.putExtra( "key", dateTV.text.toString() )
            startActivity( myIntent )
        }

        override fun onCancelled(error: DatabaseError) {
            Log.w( "MainActivity", error.toString() )
        }
    }
}