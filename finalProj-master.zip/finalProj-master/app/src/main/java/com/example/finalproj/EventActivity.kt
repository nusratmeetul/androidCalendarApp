package com.example.finalproj

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

    class EventActivity : AppCompatActivity() {
    lateinit var nameTV : EditText
    lateinit var timeStartTV : EditText
    lateinit var timeEndTV : EditText
    lateinit var okBtn : Button
    lateinit var delBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView( R.layout.activity_event )

        var eventParams : String = intent.getStringExtra( "eventParam" )!!
        var eventParamsSplit : List<String> = eventParams.split( "," )

        nameTV = findViewById( R.id.eventNameET )
        timeStartTV = findViewById( R.id.startTimeET )
        timeEndTV = findViewById( R.id.endTimeET )
        okBtn = findViewById( R.id.okButton )
        delBtn = findViewById( R.id.delButton )

        // Set initial values of the EditText views
        if ( !eventParams.isEmpty() ) {
            nameTV.setText( eventParamsSplit[0] )
            timeStartTV.setText( eventParamsSplit[1] )
            timeEndTV.setText( eventParamsSplit[2] )
        }

        delBtn.setOnClickListener {
            val intent = Intent()
            intent.putExtra( "retVal", "delete" )
            intent.putExtra( "oldEvent", eventParams )
            setResult( Activity.RESULT_OK, intent )
            goBack()
        }

        okBtn.setOnClickListener {
            var eventName : String = nameTV.text.toString()
            var eventStart : String = timeStartTV.text.toString()
            var eventEnd : String = timeEndTV.text.toString()

            // TODO( "Add onto this if statement to include checks on the other two parameters" )
            // The other two parameters need to be checked for whether they have
            // given a proper start and end time.
            // This should also account for different formats if necessary
            if ( eventName.isNotBlank() ) {
                val intent = Intent()
                intent.putExtra( "retEvent", eventName + "," + eventStart + "," + eventEnd )
                if ( eventParams.isNotBlank() ) {
                    intent.putExtra("retVal", "replace")
                    intent.putExtra("oldEvent", eventParams)
                }
                else
                    intent.putExtra( "retVal", "add" )
                setResult( Activity.RESULT_OK, intent )
                goBack()
            }
        }
    }

    fun goBack() : Unit {
        this.finish()
    }
}