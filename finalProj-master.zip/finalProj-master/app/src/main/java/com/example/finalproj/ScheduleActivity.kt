package com.example.finalproj

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import android.widget.ToggleButton

class ScheduleActivity : AppCompatActivity() {
    lateinit var backBtn : Button
    lateinit var addBtn : Button
    // Key is the date
    var key : String = ""
    // Events if the events of the day
    var events : String = ""
    var firebase : FirebaseDatabase = FirebaseDatabase.getInstance()

    // for the 24 hour view
    private lateinit var timeBar12Hour: View
    private lateinit var timeBar24Hour: View
    private lateinit var timeFormatToggle: ToggleButton
    private lateinit var pref : SharedPreferences
    private var dateFormatting : Boolean = false

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView( R.layout.activity_schedule )

        events = intent.getStringExtra( "events" )!!
        key = intent.getStringExtra( "key" )!!
        backBtn = findViewById( R.id.backButton )
        addBtn = findViewById( R.id.addButton )
        timeBar12Hour = findViewById(R.id.timeBar12Hour)
        timeBar24Hour = findViewById(R.id.timeBar24Hour)
        timeFormatToggle = findViewById( R.id.timeFormatToggle )
        pref = this.getSharedPreferences( this.packageName + "_preferences",
            Context.MODE_PRIVATE )
        dateFormatting = pref.getBoolean( "24 Hour format", false )

        timeFormatToggle.isChecked = dateFormatting
        createButtons(events)

        addBtn.setOnClickListener {
            val intent = Intent(this, EventActivity::class.java )
            intent.putExtra( "eventParam", "" )
            someActivityResultLauncher.launch( intent )
        }

        backBtn.setOnClickListener {
            goBack()
        }

        // for 24 hour view
        timeFormatToggle.setOnCheckedChangeListener { _, isChecked ->
            val pref : SharedPreferences =
                this.getSharedPreferences( this.packageName + "_preferences",
                    Context.MODE_PRIVATE )
            val editor : SharedPreferences.Editor = pref.edit()
            if (isChecked) {
                editor.putBoolean( "24 Hour format", true )
                timeBar12Hour.visibility = View.GONE
                timeBar24Hour.visibility = View.VISIBLE
            } else {
                editor.putBoolean( "24 Hour format", false )
                timeBar12Hour.visibility = View.VISIBLE
                timeBar24Hour.visibility = View.GONE
            }
            editor.apply()
        }
    }

    fun goBack() : Unit {
        this.finish()
    }

    fun createButtons( eventString : String ) {
        // Create events as buttons for interactive design
        // Split the events string passed in from CalendarActivity
        val splitEvents : List<String> = eventString.split( ";" )
        // Loop through the events
        for ( i in splitEvents ) {
            if ( i.isNotBlank() ) {
                val packageName = applicationContext.packageName
                val layoutIDString12 = packageName + ":id/timeBar12Hour"
                val layoutIDString24 = packageName + ":id/timeBar24Hour"
                val resourceId12hr = resources.getIdentifier( layoutIDString12, null, packageName )
                val resourceId24hr = resources.getIdentifier( layoutIDString24, null, packageName )
                val layout12 : LinearLayout = findViewById( resourceId12hr )
                val layout24 : LinearLayout = findViewById( resourceId24hr )
                val splitParams = i.split(",")
                val tv12 : TextView = layout12.findViewWithTag( splitParams[1] )
                val tv24 : TextView = layout24.findViewWithTag( splitParams[1] )
                tv12.text = i
                tv12.textSize = 25f
                tv24.text = i
                tv24.textSize = 25f
            }
        }
    }

    val someActivityResultLauncher = registerForActivityResult( ActivityResultContracts.StartActivityForResult() ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val returnVal : String = data?.getStringExtra( "retVal" )!!
            val returnEvent : String = data.getStringExtra( "retEvent" )!!
            when ( returnVal ) {
                "add" -> {
                    if ( events.isBlank() )
                        events += returnEvent
                    else
                        events += ";$returnEvent"
                    createButtons( events )
                }
                "delete" -> {
                    val oldEvent : String = data.getStringExtra( "oldEvent" )!!
                    events = events.replace( oldEvent, "" )
                    createButtons( events )
                }
                "replace" -> {
                    val oldEvent : String = data.getStringExtra( "oldEvent" )!!
                    events = events.replace( oldEvent, returnEvent )
                    createButtons( events )
                }
            }
            // Set the value in remote database to include the events of the selected day
            val reference : DatabaseReference = firebase.getReference( key )
            reference.setValue( events )
        }
    }
}